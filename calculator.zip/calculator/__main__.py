"""This module is used to call the main function from src package"""
from src.main.main import main

if __name__ == '__main__':
    main()
