import unittest
import exponential_function


class MyTestCase(unittest.TestCase):
    def test_positive_exp(self):
        self.assertEqual(exponential_function.exponential_func(2), 2.71828182846 ** 2)

    def test_negative_exp(self):
        self.assertEqual(exponential_function.exponential_func(-2), 2.71828182846 ** -2)

    def test_zero_exp(self):
        self.assertEqual(exponential_function.exponential_func(0), 2.71828182846 ** 0)

    def test_pos_decimal_exp(self):
        self.assertEqual(exponential_function.exponential_func(8.6), 2.71828182846 ** 8.6)

    def test_neg_decimal_exp(self):
        self.assertEqual(exponential_function.exponential_func(-8.6), 2.71828182846 ** -8.6)


if __name__ == '__main__':
    unittest.main()
