"""This module is used to write main function"""
import sys
from src.calci.exponential_function import exponential_func


def main():
    """This main function is used to get input from user and call the exponential_function"""
    power = sys.argv[1]
    print(exponential_func(power))
