"""This module is used for calculating scientific operation(e^x)"""


def exponential_func(power_value):
    """This function is used to calculate the exponential function"""
    exp_value = 2.71828182846
    return exp_value ** power_value
