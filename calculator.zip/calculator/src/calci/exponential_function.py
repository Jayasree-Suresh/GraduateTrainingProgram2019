"""This module is used for calculating scientific operation(e^x)"""
import logging
logging.basicConfig(filename='logger.log', level=logging.ERROR,
                    format='%(asctime)s:%(levelname)s:%(message)s', filemode='w')


def exponential_func(power_value):
    """This function is used to calculate the exponential function"""
    try:
        exp_value = 2.71828182846
        return exp_value ** float(power_value)
    except ValueError as e:
        logging.error(e)
        print(e)
        return "Please enter float or integer types input."
