import exponential_function
if __name__ == '__main__':
    exponential_function.main()