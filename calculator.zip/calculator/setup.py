from setuptools import setup

setup(
    name='expfunc_egg',
    version='1.0.3',
    packages=[''],
    url='',
    # entry_points = {'setuptools.installation': ['expfunc_egg = exponential_function:main'], },
    py_modules=['calculator\main:main'],
    license='',
    author='jayasree.suresh',
    author_email='',
    description=''

)
